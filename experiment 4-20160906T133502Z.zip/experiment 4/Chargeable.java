package Exp4;

public interface Chargeable {
	public boolean isAvailable();
	public void charging();
	public void completedCharging();
	public void decreaseC();
}
