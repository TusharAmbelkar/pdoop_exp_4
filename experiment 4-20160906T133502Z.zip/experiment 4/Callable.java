package Exp4;

public interface Callable {
	public void call();
	public void call_end(int a);
}
